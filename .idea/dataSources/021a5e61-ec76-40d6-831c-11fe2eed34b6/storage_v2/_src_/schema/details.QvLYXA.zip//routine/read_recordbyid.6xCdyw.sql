create procedure read_recordById(IN emp_id int)
  BEGIN 
      SELECT * FROM STUDENT WHERE ID = emp_id; 
   END;

