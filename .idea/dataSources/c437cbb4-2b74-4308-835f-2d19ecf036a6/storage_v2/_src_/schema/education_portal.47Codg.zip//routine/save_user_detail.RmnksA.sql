create procedure save_user_detail(IN in_user_id int, IN in_lecture_id int, OUT out_result tinyint(1))
  BEGIN
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN



	END;
END;

