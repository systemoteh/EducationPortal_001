create procedure unblock_lecture(IN in_user_id int, IN in_lecture_id int, OUT out_result tinyint(1))
  BEGIN
    DECLARE local_user_coins INT(11);
    SET out_result = FALSE;
    SELECT coins INTO local_user_coins FROM user_detail WHERE user_id = in_user_id;
    IF (local_user_coins >= 20)
    THEN
      UPDATE user_detail SET coins = local_user_coins - 20 WHERE user_id = in_user_id;
      INSERT INTO user___lecture (user_id, lecture_id) VALUES (in_user_id, in_lecture_id);
      SET out_result = true;
    END IF;
  END;

