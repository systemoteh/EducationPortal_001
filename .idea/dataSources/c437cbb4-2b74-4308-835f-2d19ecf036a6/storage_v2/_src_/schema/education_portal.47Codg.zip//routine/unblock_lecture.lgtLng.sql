create procedure unblock_lecture(IN in_user_id int, IN in_lecture_id int, OUT out_result tinyint(1))
  BEGIN
    DECLARE temp_user_coins INT(11); -- delete
    DECLARE temp_lecture_cost INT; -- delete
    DECLARE temp_user_id_lecture_id INT;
    SET temp_user_coins = 0;
    SET temp_lecture_cost = 1000000;
    SET temp_user_id_lecture_id = 0;
    SET out_result = FALSE;
    SET autocommit = 0;
    START TRANSACTION;
    SELECT coins
        INTO temp_user_coins FROM user_detail WHERE user_id = in_user_id;
    SELECT cost
        INTO temp_lecture_cost FROM lecture WHERE id = in_lecture_id;
    SELECT COUNT(1)
        INTO temp_user_id_lecture_id
    FROM user___lecture
    WHERE user_id = in_user_id
      AND lecture_id = in_lecture_id;
    IF (temp_user_coins >= temp_lecture_cost AND temp_user_id_lecture_id = 0)
    THEN
      UPDATE user_detail SET coins = temp_user_coins - temp_lecture_cost WHERE user_id = in_user_id;
      INSERT INTO user___lecture (user_id, lecture_id) VALUES (in_user_id, in_lecture_id);
      COMMIT;
      SET out_result = true;
    END IF;
  END;

