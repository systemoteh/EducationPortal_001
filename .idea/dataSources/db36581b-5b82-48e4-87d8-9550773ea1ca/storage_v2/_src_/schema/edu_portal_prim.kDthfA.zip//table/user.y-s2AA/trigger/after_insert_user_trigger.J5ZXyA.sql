create trigger after_insert_user_trigger
  after INSERT
  on user
  for each row
BEGIN
INSERT INTO user_detail (user_id, first_name, last_name, e_mail, birth_date, coins, experience, gender, country, city, enabled, first_visit, last_visit)
VALUES (NEW.id, NEW.username, NULL, NULL, NULL, 150, 0, 0, NULL, NULL, 1, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
END;

